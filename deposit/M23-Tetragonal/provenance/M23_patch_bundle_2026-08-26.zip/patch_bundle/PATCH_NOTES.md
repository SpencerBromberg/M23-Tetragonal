# Patch bundle: M23 optimal tetragonal normalization (2026-08-26)

Companion to `M23_tetragonal_peer_review_2026-08-26`. Everything here was
produced from the published package contents alone (tables, logs, Magma
source); no external data. All scripts are pure Python 3 (stdlib + sympy
for one LLL call) and run against the package root via the
`package_root` symlink or by placing this directory inside the package.

## New certificates (all PASS, logs in `logs/`, machine output in `json/`)

1. **`scripts/verify_ramification_structure.py`** — independent geometric
   audit of all 22 flat120 tables. Certifies per prime: exact bidegree
   (4,23); totally ramified conjugate fibers at T = ±√−23 that are exact
   23rd powers at smooth points; **the exact law w(P)·t(P) = 1 at both
   totally ramified points** (new characteristic-zero identity, certified
   at 22 primes); third branch value **exactly T = 0** with tame
   multiplicity 8 and fiber cycle type 2^8 1^7 (M23 class 2A), all double
   points smooth at the 21 clean primes; Riemann–Hurwitz degree 52 on the
   t-side and 14 on the w-side; node residual of degree 124 = 2·62 with
   even multiplicities, i.e. **δ = p_a − 4: the genus-4 certificate is
   readable from the tables**; and the w-branch polynomial B (degree 14)
   isolated as the multiplicity-one part of the binary-quartic
   discriminant. Marker: `M23_RAMIFICATION_STRUCTURE_VERIFY_PASS`.
   (At p=31 one node reduces onto the T=0 fiber; recorded, clean
   structure hard-asserted at the other 21 primes.)

2. **`scripts/verify_specialization_units.py`** — certifies every
   checkable hypothesis (U1–U5) of the new Specialization Lemma at p=31,
   p=1013, and all 21 training primes, including integrality of the
   characteristic-zero input model parsed from the v68 Magma source and
   recomputation of both jet-determinant witnesses.
   Marker: `M23_SPECIALIZATION_UNITS_VERIFY_PASS`.

3. **`scripts/verify_null_model.py`** — statistical baselines: Monte
   Carlo on the actual 133-digit modulus gives null RR-candidate density
   ≈ 0.586 (analytic upper bound 6/π² ≈ 0.608; the deficit is a Wang
   stopping-rule boundary effect); the paper's 68/120 has z ≈ −0.43;
   false-survivor rate confirmed ≈ 1/1013, expected 0.067 among 68
   candidates. Marker: `M23_NULL_MODEL_VERIFY_PASS`.

4. **`scripts/verify_heldout_p1013_v2.py`** — refactored held-out
   validator: the p=1013 table is parsed from the recorded Magma log
   (single source of truth) instead of a duplicated literal; results
   cross-checked identical to the original validator.
   Marker: `M23_HELDOUT_P1013_V2_VERIFY_PASS`.

## Reconstruction attempt (certified negative)

**`scripts/branch_locus_reconstruction.py`** — CRT + ordinary/projective
Wang + per-polynomial LLL on the three canonical monic branch invariants
(g0 deg 8, h0 deg 7, B deg 14; 29 coefficients), held out at p=1013:
**0/29 reconstructed**; candidate rates at the noise floor; shortest LLL
denominators 10^114–10^119 saturate the lattice threshold. Conclusion:
even the canonical branch invariants exceed height ≈ 10^114 **in this
gauge**, so the height lives in the gauge, not in the equation's
presentation — the concrete recommendation for Open Item 1 is
gauge-folded (fractional-linear-invariant) reconstruction.
Marker: `M23_BRANCH_LOCUS_RECONSTRUCTION_NEGATIVE`.
Bonus gauge-free data recorded in the JSON: mod-p factorization types of
all three branch algebras; h0's types match GL(3,2) on 7 points
(Fano structure on the 2A fixed points), while B's types include 13- and
14-cycles (13 ∤ |M23|), i.e. the w-branch algebra looks generically S14.

## TeX patches (`tex/`, with insertion anchors in each file)

- `specialization_lemma.tex` — closes the Prop. 3.3 gap
  (semicontinuity + Grauert + unit conditions U1–U5 ↔ C1–C4).
- `thm_tetragonal_tightening.tex` — replacement proof of the tetragonal
  theorem: explicit fixed-part exclusion and degree ≤ 3 exclusion, with
  HJLPPZ Remark 3.4 quoted verbatim at the point of use.
- `prop_carrier_general_d.tex` — Prop. 8.1 restated for arbitrary
  d ≠ r² (the set {14,61,127} did no work); addresses demoted to a
  heuristic remark; the location of the burden and the circularity risk
  stated explicitly.
- `new_certificates_section.tex` — new §: the ramification-structure
  theorem, the w·t = 1 law, the genus certificate, the sharpened negative
  with height bound, the Frobenius statistics, plus a replacement
  statistical-baselines paragraph for §5 and an introduction motivation
  paragraph.

## Suggested CLAIM_STATUS edits

- Prop. 3.3: "Established + certified" → **Established** (via
  Lemma `lem:specialization` + `verify_specialization_units.py`).
- Add: Ramification-structure certificate — **Certified (22 primes)**.
- Add: Exact law w(P)t(P) = 1 — **Certified (22 primes)**, proof from the
  normalization conjectured, not yet established.
- Add: Branch-locus reconstruction — **Certified negative**
  (0/29 at 133 digits; height > 10^114 in gauge).
- Open Item 1: unchanged (open), strategy updated to gauge-folded
  invariants. Open Item 2: unchanged (open), burden restated.

## Verification

`sha256sum -c SHA256SUMS.additions` from inside this directory, then run
the five scripts; expected markers as above. Nothing in the original
package is modified.
