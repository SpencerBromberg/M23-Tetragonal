# Historical patch-bundle replay

**Archive status:** This directory preserves an intermediate pre-closure patch. The final manuscript and current-facing root documentation supersede the provisional open-item and claim-status language in `PATCH_NOTES.md`. See `ARCHIVE_NOTE.md`.

Place this directory inside the package root (or symlink the package root
as ./package_root) and run:

    python3 scripts/verify_specialization_units.py
    python3 scripts/verify_ramification_structure.py
    python3 scripts/branch_locus_reconstruction.py   # needs the json/ from the previous step
    python3 scripts/verify_null_model.py
    python3 scripts/verify_heldout_p1013_v2.py

Expected markers: see PATCH_NOTES.md.
