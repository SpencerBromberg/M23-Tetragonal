# Claim status update — v91/v92 round

| Claim | Status |
|---|---|
| Staircase multiplicities (33,1)..(41,5); 469=253+216; band counts 86 | PROVED (finite enumeration, cert1) |
| h(t,qv) = q^18 H(t,v); deg_t H <= 6; seven-band caps | VERIFIED EXACTLY over Z (cert2) |
| Exact pair RREFs to pivots (19,20); support 85/85/86; zeros 383; bands | VERIFIED over Q + mod p binding to recorded run incl. 24 fingerprints (cert3) |
| Six exact specialization identities; rank 119; kernel dim 1 over Q | RE-EXECUTED INDEPENDENTLY (cert4 log) |
| Closure logic (rank>=119 mod p; rank<=119 by elementary existence) | SOUND as restated in tex patch (circularity guard added) |
| Exact primitive relation: 120 terms, gcd 1, (4,23), 189 digits | VERIFIED (cert5 F3) |
| Held-out p=1013 vs ORIGINAL certified table | VALIDATED frame-invariantly: 1013/1013 compactified fibers; direct projective fails as frames predict (cert5) |
| 133-digit window failure | EXPLAINED: true height 189 digits |
| Explicit GL2 frame transition | OPEN (author TODO; upgrades legacy tables to coefficientwise validators) |
| Naming (Pi-decoder, Collatz binding) | RECOMMEND retirement in referee-facing text |
