# M23 tetragonal exact-closure patch bundle (2026-08-26, v91/v92 round)

Resolutions, verifications, and certifications for the v91 good-frame /
v92 exact-closure material. All certificates executed in this
environment; logs in `logs/`. Pure Python + sympy; no Magma required.

## Certificates (run: `python3 certificates/<name>.py`)
1. `cert1_forbidden_triangle_lattice.py` — PASS. Lattice lemma: 484 =
   253+231 slots; forbidden odd triangle = 15 slots with staircase
   multiplicities (33,1)...(41,5); q-pair space 469; divisibility law
   r>=18-j allows 130; seven-band law allows exactly 86
   (5+11+16+22|5+11+16). Establishes that the staircase and the (3,4,5)
   slice are lattice geometry with no arithmetic content.
2. `cert2_exact_adjoints_band_law.py` — PASS. The exact integer
   good-frame adjoints H1, H2 (copied into data/): deg_v <= 21,
   deg_t <= 6, seven-band caps hold exactly over Z, u-form coefficients
   are polynomial with deg_t a_j = 42-2j exactly, all 15 forbidden
   slots vanish. Heights: max 49 / 48 digits. (Note: H1 has 6
   incidental monomial zeros beyond the triangle — the recorded
   H*_FLAT484 nonzero count 469 refers to the pre-RREF kernel basis.)
3. `cert3_qpair_rref_binding_p100207139.py` — PASS. RREFs the exact
   pair over Q (pivot columns exactly 19, 20 = the first two
   law-allowed digits), reduces mod p=100207139, and matches the
   recorded executed-run certificate: row supports 85/85, union 86,
   common zeros 383, full support inside the seven bands, and all 24
   transcribed ROW1 fingerprint values equal. Binds the exact objects
   to the recorded Magma run.
4. `logs/cert4_v92_exact_kernel_rerun.log` — independent re-execution
   of the author certificate `M23_tetragonal_exact_kernel_certificate_v92.py`
   in this environment: all six exact integer specialization identities
   pass over Z; rank mod 1000003 = 119; kernel dimension over Q = 1;
   bidegrees (4, 23). M23_TETRAGONAL_EXACT_KERNEL_V92_PASS.
5. `cert5_frame_invariant_holdout_p1013.py` — PASS. Independent
   held-out validation the v92 pipeline never touched: the exact
   primitive vector (120 terms, gcd 1, max 189 digits) against the
   ORIGINAL certified SYMMETRIC_FLAT120 at p=1013. Direct projective
   comparison fails (expected: symmetric vs good frame, constant GL2).
   Compactified fiber factorization types agree at 1013/1013 fibers;
   the two fibers meeting W=infinity (t = 562, 782) are restored as
   rational points at infinity, confirming the Mobius/frame account in
   detail.

## Resolutions of record
- Open Item 1 (exact characteristic-zero coefficient table): CLOSED
  (cert4 logic + cert5 independent validation). CRT was discovery-only.
- q^18 divisibility law and seven-band support: promoted from inference
  to recorded + exact certification (cert2, cert3).
- Earlier negative LLL/CRT certificate: explained quantitatively
  (189-digit height > 133-digit window); gauge-height hypothesis
  confirmed (49-digit good-frame adjoints).
- Pi-decoder staircase / (3,4,5) / Euclidean corollary: lattice
  geometry (cert1); recommend deletion of the corollary and renaming
  throughout (see tex/ patch, final comment block).

## TeX
`tex/patch_v92_resolutions.tex` — paste-ready: band-law lemma +
proposition, exact-closure theorem with the circularity guard
(elementary existence only), frame remark with the 1013/1013 result,
height-accounting remark.

## Author TODO (recommended)
- Compute and publish the explicit constant GL2 transition
  symmetric <-> good frame; legacy tables then validate coefficientwise.
- Add p=100208161 to the held-out validations.
- Record the provenance of the exact H1/H2 integers (how many primes /
  which run recovered them) for the paper's data section.
