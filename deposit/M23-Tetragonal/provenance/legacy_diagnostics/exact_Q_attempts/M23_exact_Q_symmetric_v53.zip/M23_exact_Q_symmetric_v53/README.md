# M23 exact-Q symmetric tetragonal route v53

Purpose
-------
Compute the optimal degree-4 relation directly over Q, eliminating CRT
reconstruction if the exact computation completes.

Key point
---------
Over Q, q=t^2+23 is irreducible.  The two conjugate totally ramified points
form one degree-2 place P23 with residue field Q(sqrt(-23)).

For a residue x at P23, write uniquely

    x = A + B*tau,   tau^2 = -23.

The pair (A,B) is exactly the trace / divided-skew-trace information used in
the split-prime symmetric frame.  Thus the construction can be performed
over Q without choosing either conjugate point separately.

Run order
---------
1. M23_Magma_ExactQ_FrameOnly_v53.m
   Stop after the exact 2-dimensional kernel and first-jet frame.  This tells
   us whether BasisOfDifferentialsFirstKind over Q clears the online limit.

2. If frame-only passes, run M23_Magma_ExactQ_FullCharpoly_v53.m.
   It computes the 23x23 multiplication matrix of w, its characteristic
   polynomial, clears denominators, produces a primitive 120-coefficient
   integer vector, and finally reduces the exact relation modulo 31.

The full run is accepted only if the reduction agrees coefficient-for-
coefficient with the already certified p=31 SYMMETRIC_FLAT120.

If this succeeds, the characteristic-zero bidegree-(23,4) polynomial is
obtained directly.  The 23-one repunit R23 should then be used as a large
independent verification modulus rather than as the reconstruction engine.
