print "M23_EXACT_Q_SYMMETRIC_BEGIN";
Q := Rationals();
A<t> := PolynomialRing(Q);
AY<u> := PolynomialRing(A);
b := [ A!0 : i in [1..23] ];
b[2] := (-31740);
b[3] := (139840);
b[4] := (399583002);
b[5] := (-145711496856) + (-6335282472)*t^2;
b[6] := (-56775283856672) + (-126169394688)*t + (-2477993869792)*t^2;
b[7] := (2353269564340584) + (90885386323584)*t + (69899701328472)*t^2;
b[8] := (149300207182735461) + (8192572384010400)*t + (7690149863466435)*t^2;
b[9] := (-18518819166678845600) + (-1840547483855390880)*t + (-181770736706490688)*t^2;
b[10] := (5230550645390156540328) + (-2949856937205019309008)*t + (-72054287980811706816)*t^2 + (-128254649443696491696)*t^3 + (-13020414497067723624)*t^4;
b[11] := (1780732430570005145756424) + (328246325556276597513504)*t + (54631308621463631478480)*t^2 + (14271579372012025978848)*t^3 + (-990949588424086241496)*t^4;
b[12] := (-76226757591131329290382566) + (18690086460439084348196768)*t + (-1792012713435085812396596)*t^2 + (813235953706896182384992)*t^3 + (66027458205719035669658)*t^4;
b[13] := (-3875581272261943207482299424) + (-1272104594358533124234481632)*t + (-28978388560551190877922912)*t^2 + (-57786540191941872595499808)*t^3 + (5516437740989208066312576)*t^4;
b[14] := (6910353957998684922380692854804) + (-1182608554123854417720035133648)*t + (412254292452214768806833373492)*t^2 + (-112352637513414760653499408224)*t^3 + (-268507225604280859145871012)*t^4 + (-2649342360462542679225805776)*t^5 + (-223024171179988438782332580)*t^6;
b[15] := (88514359848681198441339995596152) + (66671928552879672571499601603168)*t + (3059716724605899534195931323384)*t^2 + (6093776240613995660154706708800)*t^3 + (-371653155370716716161147483224)*t^4 + (138912901665864324408428455008)*t^5 + (-14667842854307851869352629528)*t^6;
b[16] := (-14822900658422153993723820208138521) + (1452165788444071252451127163115616)*t + (-1196200268441385838255312662361293)*t^2 + (152476099696291565105489515500864)*t^3 + (-18425610081301084564482099762651)*t^4 + (3884280726976625226796090157664)*t^5 + (241847438376053797282595566017)*t^6;
b[17] := (-37724221633317849821253387809988360) + (-93620123757549254929872648043284768)*t + (-11591484764381099858905769639925000)*t^2 + (-9513428443869186509439824732200896)*t^3 + (-183430444487395254543895866578136)*t^4 + (-236651664369455642319930663132960)*t^5 + (10836296771070547980591633146088)*t^6;
b[18] := (16313110767605628611806394020375426680) + (-1703402197188364617307749292365354672)*t + (2032301462095753658490946401570018888)*t^2 + (-129191517104013848445270031021659552)*t^3 + (66730153393082520871679625793751304)*t^4 + (-2396348444989357771279301994069936)*t^5 + (400540174533969410487588483397176)*t^6;
b[19] := (1042289893847058025879040880566456994672) + (1104530349771039454874170579417691649312)*t + (333274964387577672914755115261072851872)*t^2 + (177834072940944271142086313365199175072)*t^3 + (33713454389094699008417352295983275904)*t^4 + (9164364930275864576578604398808309088)*t^5 + (1384908138976241457553823117871919200)*t^6 + (153061208206234369985720974684614624)*t^7 + (20149993182414522853209191222911248)*t^8;
b[20] := (-146676777647046733368141103212933368381760) + (47248616899864784417985500825997188919648)*t + (-31059705710059767703037569543512462548640)*t^2 + (6607721732088306642342716918797881821280)*t^3 + (-1955502285158879811215641219926699021600)*t^4 + (309985639130842180423097734341104122656)*t^5 + (-43709389872759776381483477984786375904)*t^6 + (4870010697957528157139945192741841696)*t^7 + (-232445893979612361670227977985803808)*t^8;
b[21] := (-583036461536128584530382312820824598910208) + (-368473907347056952685077902822090105858432)*t + (-250848528005315471356262109412820000004480)*t^2 + (-37680222996348867437415628143362965239168)*t^3 + (-35962460177914556876631229408057982882688)*t^4 + (-781880924013941195027394050639518996608)*t^5 + (-1778174960398790720078613827770306312320)*t^6 + (6949635305793713011094772062706710400)*t^7 + (-27863654688345929867754261488819291520)*t^8;
b[22] := (11431517330337822220551952458477060842204160) + (-25809360722373312049323407405759781746499072)*t + (1790686750434671697130166091520203419410944)*t^2 + (-2397163462662484578984858522494100321357312)*t^3 + (173980809918790171381794345879079128660480)*t^4 + (-86205619580095394601076747481250376567296)*t^5 + (9150869839919949982069223354218905122304)*t^6 + (-1337829690063830893124127624391955581440)*t^7 + (175303343058828611905721103152276390400)*t^8;
b[23] := (-636600898150484328800300139882417037526114304) + (-1454239686461893222545991110390844910530811904)*t + (-352689535457875303125555026318811624811247616)*t^2 + (103352070659831277568590719722025029106073600)*t^3 + (15315119499810615305853634694027898506182656)*t^4 + (32961183987151578191197448811534368526176256)*t^5 + (4181405479539036486753938644987111713705984)*t^6 + (1801978935221572204239176449303804249128960)*t^7 + (172171892687016253525660128823927540899840)*t^8 + (29729556023869614361220075333404061337600)*t^9 + (2001532669196828324472937945546023168000)*t^10;


q := t^2 + 23;
G := u^23 + &+[ b[j]*q^(j - ((5*j) div 23))*u^(23-j) : j in [2..23] ];
assert Degree(G) eq 23;

print "CHECK 1 START: exact Q function field";
time_ff := Cputime();
X<uu> := FunctionField(G : Check := false);
print "TIME_Q_FUNCTION_FIELD =", Cputime(time_ff);
if Degree(X) ne 23 then
    error "exact Q function field degree failure";
end if;
print "CHECK 1: exact Q function field degree 23: PASS";

SetUseMontes(true);

print "CHECK 2 START: degree-two place above t^2+23";
time_p := Cputime();
Montes(X,q);
Ps := X`PrimeIdeals[q];
print "TIME_Q_MONTES_P23 =", Cputime(time_p);
if #Ps ne 1 then
    error "expected one prime above irreducible t^2+23";
end if;
P23 := Ps[1];

if Degree(P23) ne 2 then
    error "P23 should have degree 2";
end if;
if Valuation(X!q,P23) ne 23 then
    error "unexpected q valuation at P23";
end if;
if Valuation(X!uu,P23) ne 19 then
    error "unexpected u valuation at P23";
end if;
print "CHECK 2: degree-two P23 recovered with valuations (23,19): PASS";

RF := ResidueField(P23);
tau0 := Reduction(X!t,P23);
flagtau, tau := IsCoercible(RF,tau0);
if not flagtau then
    error "could not coerce t residue to P23 residue field";
end if;

tau_seq := Eltseq(tau);
while #tau_seq lt 2 do
    Append(~tau_seq,Q!0);
end while;
if #tau_seq ne 2 or tau_seq[2] eq 0 then
    error "unexpected residue-field coordinates for t";
end if;

function QPairFromResidue(x, RF, tau_seq)
    xx := Eltseq(RF!x);
    while #xx lt 2 do
        Append(~xx,Q!0);
    end while;
    if #xx ne 2 then
        error "unexpected degree-two residue coordinate length";
    end if;
    B := (Q!xx[2])/(Q!tau_seq[2]);
    A0 := (Q!xx[1]) - B*(Q!tau_seq[1]);
    return A0,B;
end function;

print "RESIDUE_T_COORDS =", [ Q!x : x in tau_seq ];
if tau^2 + RF!23 ne RF!0 then
    error "residue of t does not satisfy t^2+23";
end if;
print "CHECK 2B: residue field identifies Q(sqrt(-23)): PASS";

print "CHECK 3 START: exact holomorphic differential basis over Q";
time_diff := Cputime();
dt := Differential(X!t);
HD := BasisOfDifferentialsFirstKind(X);
print "TIME_Q_HOLOMORPHIC_DIFFERENTIAL_BASIS =", Cputime(time_diff);
print "HOLOMORPHIC_DIFFERENTIAL_BASIS_LENGTH =", #HD;

if #HD ne 4 then
    error "exact Q holomorphic differential dimension failure";
end if;

BK := [ omega/dt : omega in HD ];
print "CHECK 3: four exact canonical functions recovered: PASS";

print "CHECK 4 START: exact degree-two residue kernel L(K-(b'+c'))";

piP := (X!uu)^17/(X!q)^14;
if Valuation(piP,P23) ne 1 then
    error "exact Q local parameter valuation failure";
end if;

C := ZeroMatrix(Q,4,2);

for i in [1..4] do
    gi := BK[i]*piP^22;
    vg := Valuation(gi,P23);
    if vg lt 0 then
        error "canonical function fails P23 regularity after pi^22";
    end if;

    if vg eq 0 then
        ri0 := Reduction(gi,P23);
        flag, ri := IsCoercible(RF,ri0);
        if not flag then
            error "zeroth-jet residue coercion failure";
        end if;
        a0,b0 := QPairFromResidue(ri,RF,tau_seq);
        C[i,1] := a0;
        C[i,2] := b0;
    end if;
end for;

print "EXACT_RESIDUE_CONDITION_MATRIX =", C;
print "EXACT_RESIDUE_CONDITION_RANK =", Rank(C);

N := NullspaceMatrix(C);
print "EXACT_RESIDUE_KERNEL_DIMENSION =", Nrows(N);

if Rank(C) ne 2 or Nrows(N) ne 2 or Ncols(N) ne 4 then
    error "exact Q kernel is not dimension two";
end if;

BD := [];
for j in [1..2] do
    fj := &+[ (X!N[j,i])*BK[i] : i in [1..4] ];
    Append(~BD,fj);
end for;

print "CHECK 4: exact L(K-(b'+c')) dimension 2 recovered: PASS";

print "CHECK 5 START: exact Q(sqrt(-23)) first-jet frame";

Jker := ZeroMatrix(Q,2,2);

for i in [1..2] do
    gg := BD[i]*piP^21;
    vg := Valuation(gg,P23);
    if vg lt 0 then
        error "first-jet regularity failure";
    end if;

    if vg eq 0 then
        ri0 := Reduction(gg,P23);
        flag, ri := IsCoercible(RF,ri0);
        if not flag then
            error "first-jet residue coercion failure";
        end if;
        a1,b1 := QPairFromResidue(ri,RF,tau_seq);
        Jker[i,1] := a1;
        Jker[i,2] := b1;
    end if;
end for;

print "EXACT_KERNEL_FIRST_JET_MATRIX =", Jker;
print "EXACT_KERNEL_FIRST_JET_RANK =", Rank(Jker);

if Rank(Jker) ne 2 then
    error "exact first-jet frame is singular";
end if;

Cmap := Jker^-1;
print "EXACT_KERNEL_TO_SYMMETRIC_MATRIX =", Cmap;

S1 := (X!Cmap[1,1])*BD[1] + (X!Cmap[1,2])*BD[2];
S2 := (X!Cmap[2,1])*BD[1] + (X!Cmap[2,2])*BD[2];
w := S1/S2;

print "CHECK 5: exact Q symmetric degree-4 coordinate fixed: PASS";

print "M23_EXACT_Q_FRAME_ONLY_PASS";
