# M23 exact-Q canonical-divisor fallback v54

The v53 exact-Q run reaches P23 immediately but stalls in
BasisOfDifferentialsFirstKind(X).

v54 changes only the canonical-space engine:

    K := CanonicalDivisor(X);
    BK := Basis(K : Reduction := false, Simplification := "None");

Magma documents CanonicalDivisor(F) separately from the holomorphic-
differential basis intrinsic, so this exercises a different code path.

For a canonical divisor K and m = v_P23(K):
- f in L(K) => f*pi^m is regular at P23.
- f in L(K-P23) iff residue(f*pi^m)=0.
- for f in L(K-P23), the first jet is residue(f*pi^(m-1)).

Thus the same two-dimensional degree-4 pencil and exact Q(sqrt(-23))
trace/skew framing are recovered without requiring div(dt) or a basis of
holomorphic differentials.

Run FrameOnly first. If it reaches
    M23_EXACT_Q_CANONICALDIVISOR_FRAME_PASS
then run Full.

The full script computes the exact degree-23 characteristic polynomial and
requires bidegree (23,4). It may produce a different Q-rational Möbius
coordinate from the earlier split-prime symmetric normalization; that is
mathematically harmless because the degree-4 pencil is the same.
