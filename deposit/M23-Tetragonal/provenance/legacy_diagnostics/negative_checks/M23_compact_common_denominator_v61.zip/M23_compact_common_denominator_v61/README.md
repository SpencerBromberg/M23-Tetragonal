# M23 compact common-denominator diagnostic v61

Training CRT: 17 accepted symmetric primes, 102 digits.
Independent held-out prime: p=1163611.

The previous v60 output was too verbose: it printed full 21-dimensional
vectors for multiple rows and the pasted output reached only block 1.

v61 runs the same six 20-coefficient LLL blocks but performs the held-out
test internally. It prints only per-block summaries unless a candidate
actually survives the independent prime.

For every reduced LLL row with nonzero denominator d:

    a_j = d r_j (mod M)

is checked against the 102-digit training CRT. Training-valid rows are then
tested against the independent residues h_j:

    a_j = d h_j (mod 1163611).

A denominator divisible by the held-out prime is excluded as a degenerate
scale.

The decisive line is expected to be one of:

    M23_COMMON_DENOMINATOR_NO_HELDOUT_SURVIVOR

or

    M23_COMMON_DENOMINATOR_HELDOUT_SURVIVOR_FOUND

followed by:

    M23_COMPACT_COMMON_DENOMINATOR_PASS
