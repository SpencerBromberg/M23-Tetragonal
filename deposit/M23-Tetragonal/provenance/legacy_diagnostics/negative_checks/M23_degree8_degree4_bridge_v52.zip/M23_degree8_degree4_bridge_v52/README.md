# M23 degree-8 / degree-4 bridge diagnostic v52

Correction
----------
v51 transposed the row-coordinate matrix before NullspaceMatrix.  The output
dimensions 19=23-4 and 17=23-6 exposed the orientation error.  Consequently
the v51 line

    PREDICTED_DENOM_CONSTANT_RELATION = [0,0,0,1]

was not a relation among the four functions and its PASS line is invalid.

v52 uses three safeguards:

1. Rank of the row-coordinate matrix is printed first.
2. NullspaceMatrix is applied directly to the row matrix, so relations are
   among the candidate functions.
3. Any candidate relation must have coefficients in the constant field and
   is substituted exactly back into the function field before PASS.

Interpretation
--------------
For the predicted form, rank < 4 is necessary.
For a generic degree-(2,2) bridge, rank < 6 is necessary.

If both ranks are full (4 and 6), the quadratic-composition hypothesis is
disproved at that prime and this bridge route should be retired.

Run p=31 first.  Only if a bridge is genuinely found should p=1000003 be run.
